package com.gajanan.cablemanager

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class Customer(val id: Long, val name: String, val phone: String, val monthly: Int,
                    val activation: Long?, val expiry: Long?, val expirySmsSent: Boolean,
                    val totalAmount: Int, val paidAmount: Int) {
    val balanceAmount: Int get() = (totalAmount - paidAmount).coerceAtLeast(0)
}
data class PaymentRow(val name: String, val amount: Int, val method: String, val paidAt: String)

class CableDb(ctx: Context) : SQLiteOpenHelper(ctx, "gajanan_cable.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, monthly INTEGER NOT NULL, activation INTEGER, expiry INTEGER, expiry_sms_sent INTEGER NOT NULL DEFAULT 0, total_amount INTEGER NOT NULL DEFAULT 0, paid_amount INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, amount INTEGER, method TEXT, paid_at TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE customers ADD COLUMN expiry INTEGER")
            db.execSQL("ALTER TABLE customers ADD COLUMN expiry_sms_sent INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE customers ADD COLUMN activation INTEGER")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE customers ADD COLUMN total_amount INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE customers ADD COLUMN paid_amount INTEGER NOT NULL DEFAULT 0")
            db.execSQL("UPDATE customers SET total_amount=monthly, paid_amount=0")
        }
    }
    fun addCustomer(name: String, phone: String, amount: Int) {
        writableDatabase.insert("customers", null, ContentValues().apply {
            put("name", name); put("phone", phone); put("monthly", amount); put("total_amount", amount); put("paid_amount", 0)
        })
    }
    fun customers(): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.rawQuery("SELECT id,name,phone,monthly,activation,expiry,expiry_sms_sent,total_amount,paid_amount FROM customers ORDER BY name", null).use { c ->
            while (c.moveToNext()) out.add(Customer(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3),
                if (c.isNull(4)) null else c.getLong(4),
                if (c.isNull(5)) null else c.getLong(5), c.getInt(6) == 1, c.getInt(7), c.getInt(8)))
        }
        return out
    }
    fun recordPayment(c: Customer, amount: Int, method: String, activation: Long, expiry: Long): Long {
        writableDatabase.insert("payments", null, ContentValues().apply {
            put("customer_id", c.id); put("amount", amount); put("method", method)
            put("paid_at", SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("en","IN")).format(Date()))
        })
        writableDatabase.execSQL("UPDATE customers SET paid_amount=paid_amount+?, activation=?, expiry=?, expiry_sms_sent=0 WHERE id=?",
            arrayOf(amount, activation, expiry, c.id))
        return expiry
    }
    fun updateCustomerLedger(id: Long, total: Int, paid: Int) {
        writableDatabase.update("customers", ContentValues().apply {
            put("total_amount", total); put("paid_amount", paid)
        }, "id=?", arrayOf(id.toString()))
    }
    fun expiredUnsent(): List<Customer> = customers().filter {
        it.expiry != null && it.expiry <= System.currentTimeMillis() && !it.expirySmsSent
    }
    fun expiredCustomers(): List<Customer> = customers().filter { it.expiry != null && it.expiry <= System.currentTimeMillis() }
    fun markExpirySmsSent(customerId: Long) {
        writableDatabase.update("customers", ContentValues().apply { put("expiry_sms_sent", 1) },
            "id=?", arrayOf(customerId.toString()))
    }
    fun totalCollected(): Int = scalar("SELECT COALESCE(SUM(amount),0) FROM payments")
    fun cashCollected(): Int = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE method='Cash'")
    fun upiCollected(): Int = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE method='UPI'")
    fun paymentCount(): Int = scalar("SELECT COUNT(*) FROM payments")
    private fun scalar(sql: String): Int {
        readableDatabase.rawQuery(sql, null).use { if (it.moveToFirst()) return it.getInt(0) }
        return 0
    }
    fun recentPayments(): List<PaymentRow> {
        val out = mutableListOf<PaymentRow>()
        readableDatabase.rawQuery(
            "SELECT COALESCE(c.name,'Unknown'),p.amount,p.method,p.paid_at FROM payments p LEFT JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC LIMIT 12", null
        ).use { c ->
            while (c.moveToNext()) out.add(PaymentRow(c.getString(0), c.getInt(1), c.getString(2), c.getString(3)))
        }
        return out
    }
}

class ExpiryWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            return Result.retry()
        val db = CableDb(applicationContext)
        val expired = db.expiredUnsent()
        if (expired.isEmpty()) return Result.success()
        var failed = false
        expired.forEach { c ->
            val msg = "तुमच्या केबल रिचार्जची मुदत ${dateText(c.expiry!!)} रोजी संपली आहे. सेवा सुरू ठेवण्यासाठी कृपया रिचार्ज करा. - श्री गजानन महाराज केबल सर्व्हिस"
            try {
                @Suppress("DEPRECATION") val manager = SmsManager.getDefault()
                val parts = manager.divideMessage(msg)
                if (parts.size > 1) manager.sendMultipartTextMessage(c.phone, null, parts, null, null)
                else manager.sendTextMessage(c.phone, null, msg, null, null)
                db.markExpirySmsSent(c.id)
            } catch (_: Exception) { failed = true }
        }
        if (expired.isNotEmpty()) showExpiryNotification(applicationContext, expired.size)
        return if (failed) Result.retry() else Result.success()
    }
    private fun dateText(ms: Long) = SimpleDateFormat("dd/MM/yyyy", Locale("en","IN")).format(Date(ms))
}

fun scheduleExpiryChecks(context: Context) {
    val request = PeriodicWorkRequestBuilder<ExpiryWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "gajanan_cable_expiry_check", ExistingPeriodicWorkPolicy.KEEP, request
    )
}

fun showExpiryNotification(context: Context, count: Int) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
        manager.createNotificationChannel(NotificationChannel("expiry_alerts", "Recharge expiry alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }
    if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
        val notification = NotificationCompat.Builder(context, "expiry_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Gajanan Cable Manager")
            .setContentText("$count ग्राहकांचे रिचार्ज संपले आहे.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true).build()
        manager.notify(4102, notification)
    }
}

class MainActivity : Activity() {
    private lateinit var db: CableDb
    private val smsRequest = 701
    private val notificationRequest = 702
    private var pendingExpiryCheck = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = CableDb(this)
        scheduleExpiryChecks(this)
        requestNotificationPermissionIfNeeded()
        render()
        checkExpiriesAndAlert()
    }
    override fun onResume() {
        super.onResume()
        if (::db.isInitialized) { scheduleExpiryChecks(this); checkExpiriesAndAlert() }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun date(ms: Long) = SimpleDateFormat("dd/MM/yyyy", Locale("en","IN")).format(Date(ms))
    private fun label(s: String, size: Float = 16f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(0xFF202B27.toInt()); setPadding(dp(4), dp(7), dp(4), dp(7))
    }
    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText; textSize = 16f; setSingleLine(true)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }

    private fun render() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(24)) }
        scroll.addView(page)
        page.addView(label("श्री गजानन महाराज केबल सर्व्हिस", 22f))
        page.addView(label("GAJANAN CABLE MANAGER  •  Admin", 13f))
        page.addView(label("एकूण ग्राहक: ${db.customers().size}", 16f))
        page.addView(label("PAYMENT ANALYSIS", 19f))
        page.addView(label("एकूण जमा: ₹${db.totalCollected()}  |  व्यवहार: ${db.paymentCount()}", 17f))
        page.addView(label("Cash द्वारे: ₹${db.cashCollected()}", 16f))
        page.addView(label("UPI द्वारे: ₹${db.upiCollected()}", 16f))
        page.addView(label("EXPIRY ALERT", 19f))
        val expired = db.expiredCustomers()
        page.addView(label("Expired ग्राहक: ${expired.size}", 16f))
        expired.forEach { page.addView(label("• ${it.name} (${it.phone}) — ${date(it.expiry!!)}", 14f)) }
        page.addView(label("अलीकडील पेमेंट (शेवटचे 12)", 18f))
        val recent = db.recentPayments()
        if (recent.isEmpty()) page.addView(label("अजून पेमेंट नोंदलेले नाही.", 14f))
        recent.forEach { page.addView(label("${it.name}  •  ₹${it.amount}  •  ${it.method}\n${it.paidAt}", 14f)) }

        page.addView(label("नवीन ग्राहक जोडा", 19f))
        val name = field("ग्राहकाचे पूर्ण नाव")
        val phone = field("मोबाईल नंबर (10 अंक)"); phone.inputType = 3
        val monthly = field("मासिक रिचार्ज रक्कम (उदा. 300)"); monthly.inputType = 2
        page.addView(name); page.addView(phone); page.addView(monthly)
        page.addView(button("ग्राहक सेव्ह करा") {
            val n = name.text.toString().trim(); val p = phone.text.toString().trim(); val a = monthly.text.toString().toIntOrNull()
            if (n.isBlank() || p.length != 10 || a == null || a <= 0) toast("नाव, 10 अंकी मोबाईल नंबर आणि योग्य रक्कम भरा.")
            else { db.addCustomer(n, p, a); toast("ग्राहक सेव्ह झाला."); render() }
        })
        page.addView(label("ग्राहक आणि रिचार्ज", 19f))
        val customers = db.customers()
        if (customers.isEmpty()) page.addView(label("अजून ग्राहक जोडलेले नाहीत."))
        customers.forEach { c ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(0xFFF0F5F2.toInt()) }
            card.addView(label("${c.name}  •  ₹${c.monthly}", 17f))
            card.addView(label("${c.phone}  |  ग्राहक क्रमांक: ${c.id}", 13f))
            card.addView(label("एकूण बिल: ₹${c.totalAmount}  |  जमा: ₹${c.paidAmount}  |  बाकी: ₹${c.balanceAmount}", 14f))
            card.addView(button("बिल / जमा / बाकी Edit करा") { editCustomerLedger(c) })
            card.addView(button("बिलाचा SMS ग्राहकाला पाठवा") { sendBillSummarySms(c) })
            card.addView(label(if (c.expiry == null) "Recharge: Not started" else "Activation: ${c.activation?.let { date(it) } ?: "-"}  |  Expiry: ${date(c.expiry)}  •  " + if (c.expiry > System.currentTimeMillis()) "ACTIVE" else "EXPIRED", 13f))
            card.addView(button("पेमेंट नोंदवा आणि SMS पाठवा") { payment(c) })
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); page.addView(card, lp)
        }
        page.addView(label("Background Expiry Check: साधारण दर 15 मिनिटांनी तपासणी. Android battery restrictions मुळे नेमक्या क्षणी SMS ची हमी नाही.", 13f))
        setContentView(scroll)
    }

    private fun sendBillSummarySms(c: Customer) {
        val message = "श्री गजानन महाराज केबल सर्व्हिस\n" +
            "ग्राहक: ${c.name}\n" +
            "एकूण बिल: ₹${c.totalAmount}\n" +
            "जमा रक्कम: ₹${c.paidAmount}\n" +
            "बाकी रक्कम: ₹${c.balanceAmount}\nधन्यवाद!"
        AlertDialog.Builder(this).setTitle("बिलाचा SMS पाठवा?")
            .setMessage(message).setNegativeButton("रद्द", null)
            .setPositiveButton("SMS पाठवा") { _, _ ->
                if (sendSms(c.phone, message)) toast("SMS पाठवण्याची विनंती केली: ${c.phone}")
            }.show()
    }

    private fun editCustomerLedger(c: Customer) {
        val total = EditText(this).apply { hint = "एकूण बिल (₹)"; inputType = 2; setText(c.totalAmount.toString()) }
        val paid = EditText(this).apply { hint = "जमा रक्कम (₹)"; inputType = 2; setText(c.paidAmount.toString()) }
        val balance = label("बाकी रक्कम: ₹${c.balanceAmount}", 15f)
        fun refresh() {
            val t = total.text.toString().toIntOrNull() ?: 0
            val p = paid.text.toString().toIntOrNull() ?: 0
            balance.text = "बाकी रक्कम: ₹${t - p}"
        }
        total.addTextChangedListener(SimpleTextWatcher { refresh() })
        paid.addTextChangedListener(SimpleTextWatcher { refresh() })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(5))
            addView(label("${c.name} – बिल तपशील"))
            addView(label("एकूण बिल (₹)", 13f)); addView(total)
            addView(label("जमा रक्कम (₹)", 13f)); addView(paid)
            addView(balance)
        }
        AlertDialog.Builder(this).setTitle("बिल तपशील Edit करा").setView(box)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("Save") { _, _ ->
                val t = total.text.toString().toIntOrNull()
                val p = paid.text.toString().toIntOrNull()
                if (t == null || p == null || t < 0 || p < 0 || p > t) {
                    toast("योग्य रक्कम भरा. जमा रक्कम एकूण बिलापेक्षा जास्त नसावी.")
                    return@setPositiveButton
                }
                db.updateCustomerLedger(c.id, t, p)
                toast("बिल तपशील अपडेट झाले.")
                render()
            }.show()
    }

    private class SimpleTextWatcher(val changed: () -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }

    private fun payment(c: Customer) {
        val amount = EditText(this).apply { hint = "प्राप्त रक्कम (₹)"; inputType = 2; setText(c.monthly.toString()) }
        val validity = EditText(this).apply { hint = "Validity (दिवस)"; inputType = 2; setText("30") }
        val activationCal = Calendar.getInstance()
        val expiryCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 30) }
        val activationButton = Button(this).apply { text = "Activation Date: ${date(activationCal.timeInMillis)}" }
        val expiryButton = Button(this).apply { text = "Expiry Date: ${date(expiryCal.timeInMillis)}" }
        val dueCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 7) }
        val dueButton = Button(this).apply { text = "बाकी भरण्याची तारीख: ${date(dueCal.timeInMillis)}" }
        dueButton.setOnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                dueCal.set(year, month, day, 0, 0, 0)
                dueCal.set(Calendar.MILLISECOND, 0)
                dueButton.text = "बाकी भरण्याची तारीख: ${date(dueCal.timeInMillis)}"
            }, dueCal.get(Calendar.YEAR), dueCal.get(Calendar.MONTH), dueCal.get(Calendar.DAY_OF_MONTH)).show()
        }
        fun refreshDateButtons() {
            activationButton.text = "Activation Date: ${date(activationCal.timeInMillis)}"
            expiryButton.text = "Expiry Date: ${date(expiryCal.timeInMillis)}"
        }
        activationButton.setOnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                activationCal.set(year, month, day, 0, 0, 0)
                activationCal.set(Calendar.MILLISECOND, 0)
                val days = validity.text.toString().toIntOrNull() ?: 30
                expiryCal.timeInMillis = activationCal.timeInMillis
                expiryCal.add(Calendar.DAY_OF_YEAR, days)
                refreshDateButtons()
            }, activationCal.get(Calendar.YEAR), activationCal.get(Calendar.MONTH), activationCal.get(Calendar.DAY_OF_MONTH)).show()
        }
        expiryButton.setOnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                expiryCal.set(year, month, day, 23, 59, 59)
                expiryCal.set(Calendar.MILLISECOND, 999)
                refreshDateButtons()
            }, expiryCal.get(Calendar.YEAR), expiryCal.get(Calendar.MONTH), expiryCal.get(Calendar.DAY_OF_MONTH)).show()
        }
        validity.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val days = validity.text.toString().toIntOrNull()
                if (days != null && days in 1..3650) {
                    expiryCal.timeInMillis = activationCal.timeInMillis
                    expiryCal.add(Calendar.DAY_OF_YEAR, days)
                    refreshDateButtons()
                }
            }
        }
        val methods = arrayOf("Cash", "UPI")
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, methods) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(5))
            addView(label("${c.name} यांचे पेमेंट"))
            addView(label("प्राप्त रक्कम (₹)", 13f)); addView(amount)
            addView(label("Custom Validity (दिवस)", 13f)); addView(validity)
            addView(activationButton)
            addView(expiryButton)
            addView(dueButton)
            addView(label("Payment Method", 13f)); addView(spinner)
        }
        AlertDialog.Builder(this).setTitle("पेमेंट नोंदवा").setView(box).setNegativeButton("रद्द", null)
            .setPositiveButton("पेमेंट प्राप्त झाले") { _, _ ->
                val value = amount.text.toString().toIntOrNull()
                val days = validity.text.toString().toIntOrNull()
                if (value == null || value <= 0) { toast("योग्य रक्कम भरा."); return@setPositiveButton }
                if (days == null || days !in 1..3650) { toast("Validity 1 ते 3650 दिवसांदरम्यान भरा."); return@setPositiveButton }
                val activation = activationCal.timeInMillis
                val expiry = expiryCal.timeInMillis
                if (expiry <= activation) { toast("Expiry Date ही Activation Date नंतरची असावी."); return@setPositiveButton }
                val newPaid = c.paidAmount + value
                if (newPaid > c.totalAmount) {
                    toast("प्राप्त रक्कम एकूण बिलापेक्षा जास्त आहे. आधी बिल तपशील Edit करा.")
                    return@setPositiveButton
                }
                db.recordPayment(c, value, methods[spinner.selectedItemPosition], activation, expiry)
                val actualDays = ((expiry - activation) / 86400000L).toInt().coerceAtLeast(1)
                val remaining = (c.totalAmount - newPaid).coerceAtLeast(0)
                val dueText = date(dueCal.timeInMillis)
                val smsText = "श्री गजानन महाराज केबल सर्व्हिस\\n" +
                    "प्रिय ${c.name},\\n" +
                    "एकूण बिल: ₹${c.totalAmount}\\n" +
                    "आज जमा: ₹$value\\n" +
                    "एकूण जमा: ₹$newPaid\\n" +
                    "बाकी रक्कम: ₹$remaining\\n" +
                    (if (remaining > 0) "कृपया बाकी ₹$remaining पुढील आठवड्यात, $dueText पर्यंत भरावे.\\n" else "तुमचे संपूर्ण बिल भरले गेले आहे. धन्यवाद!\\n") +
                    "रिचार्ज Validity: $actualDays दिवस. Expiry: ${date(expiry)}"
                AlertDialog.Builder(this).setTitle("ग्राहकाला SMS पाठवायचा?")
                    .setMessage(smsText).setNegativeButton("नंतर", null)
                    .setPositiveButton("SMS पाठवा") { _, _ -> sendSms(c.phone, smsText) }
                    .show()
                render()
            }.show()
    }

    private fun checkExpiriesAndAlert() {
        val expired = db.expiredCustomers()
        if (expired.isNotEmpty()) {
            AlertDialog.Builder(this).setTitle("Recharge Expiry Alert")
                .setMessage("${expired.size} ग्राहकांचे रिचार्ज संपले आहे:\n" + expired.joinToString("\n") { "• ${it.name} - ${it.phone}" })
                .setPositiveButton("ठीक आहे", null).show()
        }
        if (db.expiredUnsent().isNotEmpty() && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED && !pendingExpiryCheck) {
            pendingExpiryCheck = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), smsRequest)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
        }
    }

    private fun sendSms(phone: String, message: String): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), smsRequest); return false
        }
        return try {
            @Suppress("DEPRECATION") val manager = SmsManager.getDefault()
            val parts = manager.divideMessage(message)
            if (parts.size > 1) manager.sendMultipartTextMessage(phone, null, parts, null, null)
            else manager.sendTextMessage(phone, null, message, null, null)
            true
        } catch (e: Exception) { toast("SMS पाठवता आला नाही: ${e.message}"); false }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsRequest) {
            pendingExpiryCheck = false
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                val unsent = db.expiredUnsent()
                unsent.forEach { c ->
                    val sent = sendSms(c.phone, "तुमच्या केबल रिचार्जची मुदत ${date(c.expiry!!)} रोजी संपली आहे. सेवा सुरू ठेवण्यासाठी कृपया रिचार्ज करा. - श्री गजानन महाराज केबल सर्व्हिस")
                    if (sent) db.markExpirySmsSent(c.id)
                }
            } else toast("SMS परवानगी नाकारली. SMS पाठवले जाणार नाहीत.")
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
