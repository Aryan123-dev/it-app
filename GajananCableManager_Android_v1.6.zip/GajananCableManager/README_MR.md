# Gajanan Cable Manager – Android starter v1.2

## या आवृत्तीत
- ग्राहक नोंदणी आणि ग्राहकांची यादी
- Cash / UPI पेमेंट नोंदणी
- प्रत्येक पेमेंटनंतर 30 दिवसांची वैधता
- Recharge confirmation SMS (फोनच्या SIM मधून)
- WorkManager द्वारे background expiry तपासणी (साधारण 15 मिनिटांच्या interval ने)
- Expired ग्राहकांसाठी Admin in-app alert आणि Android notification
- Expired SMS एकदाच पाठवण्याची local flag नोंद
- Payment Analysis: एकूण जमा, Cash जमा, UPI जमा, व्यवहारांची संख्या
- शेवटचे 12 पेमेंट: ग्राहक, रक्कम, पद्धत, वेळ
- SQLite local storage

## Android Studio मध्ये चालवणे
1. ZIP extract करा.
2. Android Studio → Open → `GajananCableManager` folder.
3. Gradle Sync करा (internet आवश्यक; WorkManager dependency download होईल).
4. Android फोनवर Run करा आणि SMS / Notification permissions द्या.

## महत्त्वाच्या मर्यादा
- हा Android Studio source project आहे; compiled APK नाही. या वातावरणात Android SDK/Gradle build उपलब्ध नाही.
- Background expiry checks WorkManager द्वारे साधारण 15 मिनिटांनी चालतात. Android Doze, battery optimization, manufacturer restrictions आणि network/OS scheduling मुळे अचूक expiry क्षणी SMS जाण्याची हमी देता येत नाही. Force-stop केलेल्या app चे काम app पुन्हा सुरू होईपर्यंत थांबू शकते.
- SMS SIM मधून जातो; SIM balance, network, operator charges आणि SMS permission आवश्यक. Android send API ने स्वीकारले म्हणजे handset delivery confirmed असे नाही.
- Payment analysis सर्व नोंदवलेल्या व्यवहारांचा एकूण हिशेब दाखवते; शेवटचे 12 व्यवहार दाखवते. CSV/PDF export व date-wise/month-wise filters अजून नाहीत.
- UPI ची बँक-साइड automatic verification नाही. Admin ने पैसे प्रत्यक्ष मिळाल्याची खात्री करूनच UPI पेमेंट नोंदवावे.
- Data सध्या त्या फोनवरील SQLite मध्ये आहे; cloud sync/backup नाही. फोन बदलण्यापूर्वी backup सुविधा आवश्यक.
- SMS permission वर Google Play चे धोरण कठोर आहे; वितरणापूर्वी धोरण तपासा.

## Version 1.5 – Custom validity
- Payment dialog मध्ये Validity (दिवस) field जोडले आहे.
- Default validity 30 दिवस आहे; Admin प्रत्येक recharge साठी 1 ते 3650 दिवस निवडू शकतो.
- Expiry date निवडलेल्या दिवसांवरून मोजली जाते.
- Confirmation SMS मध्ये निवडलेले validity days आणि expiry date दिसते.

## Version 1.6 – Editable activation and expiry dates
- Payment dialog मध्ये Activation Date आणि Expiry Date साठी स्वतंत्र date pickers.
- Activation date बदलल्यावर expiry date custom validity नुसार पुन्हा मोजली जाते.
- Expiry date manually बदलता येते.
- Expiry date activation date नंतरची असणे आवश्यक.
- Customer card वर Activation आणि Expiry दोन्ही तारखा दिसतात.
- SQLite schema v3 मध्ये activation date साठवली जाते; आधीचा v2 database upgrade होतो.
